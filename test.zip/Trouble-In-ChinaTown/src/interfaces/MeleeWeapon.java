package interfaces;

public interface MeleeWeapon extends Weapon {

}
