package interfaces;

/**
 * Enum for the different types a entity can be
 * @author laudernich1
 *
 */
public enum EntityType {
	FIRE,
	WATER,
	EARTH,
}
