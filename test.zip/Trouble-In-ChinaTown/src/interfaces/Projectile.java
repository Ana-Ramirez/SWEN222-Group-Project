package interfaces;

public interface Projectile extends Weapon {

}
