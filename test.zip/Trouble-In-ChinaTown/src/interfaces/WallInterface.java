package interfaces;

public interface WallInterface extends Entity{
	
	/**
	 * @return		position of the wall
	 */
	public String getPosition();
		
}
